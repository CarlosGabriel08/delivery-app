import React from "react"
import {View,Text, TextInput,Image} from "react-native"

export default function Formulario (){
    return(
        <View>
            <Text></Text>
        </View>
    )
}